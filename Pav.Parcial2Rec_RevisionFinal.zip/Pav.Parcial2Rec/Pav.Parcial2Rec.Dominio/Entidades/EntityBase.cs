﻿namespace Pav.Parcial2Rec.Dominio.Entidades;

public abstract class EntityBase
{
    public Guid Id { get; set; }
}
