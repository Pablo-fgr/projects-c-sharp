﻿namespace Pav.Parcial2Rec.Presentacion.Enums;

public enum Mensaje
{
    EXITO = 0, ERROR, ADVERTENCIA
}
